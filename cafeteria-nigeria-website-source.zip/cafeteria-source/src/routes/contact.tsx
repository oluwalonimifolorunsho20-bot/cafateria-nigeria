import { createFileRoute } from "@tanstack/react-router";
import { Clock, Instagram, MapPin, Phone } from "lucide-react";
import { ContactActions } from "@/components/site/ContactActions";
import { OpenStatusBadge } from "@/components/site/OpeningHours";
import { Reveal, SectionHeading } from "@/components/site/Reveal";
import {
  PHONE_NUMBER_CONFIRMED,
  RESTAURANT,
  RESTAURANT_PHONE_NUMBER,
} from "@/lib/restaurant";

const TITLE = "Contact | Cafeteria Nigeria, Victoria Island Lagos";
const DESCRIPTION =
  "Call, WhatsApp or get directions to Cafeteria Nigeria at 16B Akin Adesola Street, Victoria Island, Lagos.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <section className="mx-auto max-w-5xl px-5 py-16 lg:px-8 lg:py-24">
      <SectionHeading
        script="Say hello"
        eyebrow="Contact"
        title="Contact Cafeteria"
        intro="We answer fastest on WhatsApp — for reservations, enquiries and large tables."
      />

      <Reveal className="mt-12">
        <ContactActions />
      </Reveal>

      <div className="mt-14 grid gap-6 sm:grid-cols-2">
        <Reveal className="card-elegant p-7">
          <MapPin className="size-5 text-gold" />
          <h2 className="mt-4 text-xl">Address</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            {RESTAURANT.address.line1}
            <br />
            {RESTAURANT.address.line2}
            <br />
            {RESTAURANT.address.country}
          </p>
        </Reveal>

        <Reveal delay={80} className="card-elegant p-7">
          <Phone className="size-5 text-gold" />
          <h2 className="mt-4 text-xl">Phone & WhatsApp</h2>
          {PHONE_NUMBER_CONFIRMED ? (
            <p className="mt-3 text-sm text-muted-foreground">{RESTAURANT_PHONE_NUMBER}</p>
          ) : (
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              The restaurant's number has not been confirmed for this site yet. It is stored as a
              single editable value (<code className="text-foreground">RESTAURANT_PHONE_NUMBER</code>)
              so the call and WhatsApp buttons start working the moment it's filled in.
            </p>
          )}
        </Reveal>

        <Reveal delay={140} className="card-elegant p-7">
          <Clock className="size-5 text-gold" />
          <h2 className="mt-4 text-xl">Hours</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Mon – Thu & Sun: 8:00 AM – 10:00 PM
            <br />
            Fri & Sat: Open 24 hours
          </p>
          <div className="mt-4">
            <OpenStatusBadge />
          </div>
        </Reveal>

        <Reveal delay={200} className="card-elegant p-7">
          <Instagram className="size-5 text-gold" />
          <h2 className="mt-4 text-xl">Instagram</h2>
          <a
            href={`https://www.instagram.com/${RESTAURANT.instagramHandle.replace("@", "")}`}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-block text-sm text-gold hover:underline"
          >
            {RESTAURANT.instagramHandle}
          </a>
        </Reveal>
      </div>
    </section>
  );
}
