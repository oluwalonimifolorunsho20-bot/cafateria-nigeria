import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/site/Reveal";
import { BUBBLE_TEA, SMOOTHIE_BASES, SMOOTHIE_EXTRAS } from "@/lib/menu";
import { whatsappHref } from "@/lib/restaurant";
import { cn } from "@/lib/utils";
import bubbleTeaImg from "@/assets/bubble-tea.jpg";
import smoothieImg from "@/assets/smoothie.jpg";

function Chip({
  active,
  onClick,
  children,
  tone = "light",
}: {
  active: boolean;
  onClick: () => void;
  children: string;
  tone?: "light" | "dark";
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "border px-3 py-2 text-[0.65rem] tracking-[0.16em] uppercase transition-colors",
        active
          ? "border-gold bg-gold text-gold-foreground"
          : tone === "dark"
            ? "border-charcoal-foreground/25 text-charcoal-foreground/70 hover:border-gold/60"
            : "border-border text-muted-foreground hover:border-foreground/40",
      )}
    >
      {children}
    </button>
  );
}

export function SmoothieBuilder() {
  const [base, setBase] = useState(SMOOTHIE_BASES[0]!);
  const [extras, setExtras] = useState<string[]>([]);

  const toggle = (name: string) =>
    setExtras((list) => (list.includes(name) ? list.filter((n) => n !== name) : [...list, name]));

  const message = `Hello Cafeteria Nigeria, I'd like to build my own smoothie.\nBase: ${base}${
    extras.length ? `\nAdd-ins: ${extras.join(", ")}` : ""
  }`;

  return (
    <section className="bg-secondary/60 py-20 lg:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-[1fr_1.1fr] lg:px-8">
        <img
          src={smoothieImg}
          alt="Fresh smoothies at Cafeteria Nigeria"
          loading="lazy"
          width={1024}
          height={1024}
          className="w-full object-cover"
        />
        <div>
          <SectionHeading
            eyebrow="Smoothies"
            title="Build Your Own Smoothie"
            align="left"
            intro="Pick a fruit base, then add what you like. Add-in charges are confirmed in-store — ask us on WhatsApp and we'll quote you before you order."
          />
          <p className="eyebrow mt-8">Choose a base</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {SMOOTHIE_BASES.map((b) => (
              <Chip key={b} active={base === b} onClick={() => setBase(b)}>
                {b}
              </Chip>
            ))}
          </div>
          <p className="eyebrow mt-7">Add-ins</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {SMOOTHIE_EXTRAS.map((e) => (
              <Chip key={e.name} active={extras.includes(e.name)} onClick={() => toggle(e.name)}>
                {e.surcharge ? `${e.name} +₦${e.surcharge.toLocaleString("en-NG")}` : e.name}
              </Chip>
            ))}
          </div>
          <div className="mt-8">
            <Button asChild variant="charcoal" size="xl">
              <a href={whatsappHref(message)} target="_blank" rel="noreferrer">
                <MessageCircle /> Send My Smoothie
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

const TEA_TABS = [
  { id: "milkTea", label: "Milk Tea" },
  { id: "icedTea", label: "Iced Tea" },
  { id: "lowSugar", label: "Low / Zero Sugar" },
] as const;

export function BubbleTeaSpot() {
  const [tab, setTab] = useState<(typeof TEA_TABS)[number]["id"]>("milkTea");
  const [flavour, setFlavour] = useState<string | null>(null);
  const [sweetness, setSweetness] = useState(BUBBLE_TEA.sweetness[1]!);
  const [toppings, setToppings] = useState<string[]>([]);

  const flavours = BUBBLE_TEA[tab];
  const toggleTopping = (t: string) =>
    setToppings((list) => (list.includes(t) ? list.filter((x) => x !== t) : [...list, t]));

  const message = `Hello Cafeteria Nigeria, I'd like a bubble tea.\nStyle: ${
    TEA_TABS.find((t) => t.id === tab)!.label
  }\nFlavour: ${flavour ?? "—"}\nSweetness: ${sweetness}${
    toppings.length ? `\nToppings: ${toppings.join(", ")}` : ""
  }`;

  return (
    <section className="bg-charcoal py-20 text-charcoal-foreground lg:py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHeading
          script="The"
          eyebrow="Bubble Tea Spot"
          title="Bubble Tea Spot"
          tone="dark"
          intro="Milk teas, iced teas and low-sugar brews. Choose your flavour, sweetness and toppings."
        />

        <div className="mt-12 grid gap-12 lg:grid-cols-[1.15fr_1fr]">
          <div>
            <div className="flex flex-wrap gap-2">
              {TEA_TABS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setTab(t.id);
                    setFlavour(null);
                  }}
                  className={cn(
                    "border px-4 py-2 text-[0.65rem] tracking-[0.2em] uppercase transition-colors",
                    tab === t.id
                      ? "border-gold bg-gold text-gold-foreground"
                      : "border-charcoal-foreground/25 text-charcoal-foreground/70 hover:border-gold/60",
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              {flavours.map((f) => (
                <Chip key={f} tone="dark" active={flavour === f} onClick={() => setFlavour(f)}>
                  {f}
                </Chip>
              ))}
            </div>

            <p className="eyebrow mt-8">Sweetness</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {BUBBLE_TEA.sweetness.map((s) => (
                <Chip key={s} tone="dark" active={sweetness === s} onClick={() => setSweetness(s)}>
                  {s}
                </Chip>
              ))}
            </div>

            <p className="eyebrow mt-7">Toppings</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {BUBBLE_TEA.toppings.map((t) => (
                <Chip
                  key={t}
                  tone="dark"
                  active={toppings.includes(t)}
                  onClick={() => toggleTopping(t)}
                >
                  {t}
                </Chip>
              ))}
            </div>

            <div className="mt-9">
              <Button asChild variant="gold" size="xl">
                <a href={whatsappHref(message)} target="_blank" rel="noreferrer">
                  <MessageCircle /> Order on WhatsApp
                </a>
              </Button>
            </div>
          </div>

          <img
            src={bubbleTeaImg}
            alt="Bubble tea selection at Cafeteria Nigeria"
            loading="lazy"
            width={1024}
            height={1024}
            className="w-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
