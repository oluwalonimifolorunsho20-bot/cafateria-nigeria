import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

import acai from "@/assets/acai.jpg";
import benedict from "@/assets/benedict.jpg";
import bubbleTea from "@/assets/bubble-tea.jpg";
import chickenWaffle from "@/assets/chicken-waffle.jpg";
import coffee from "@/assets/coffee.jpg";
import dessert from "@/assets/dessert.jpg";
import hero from "@/assets/hero.jpg";
import panini from "@/assets/panini.jpg";
import pancakes from "@/assets/pancakes.jpg";
import skillet from "@/assets/skillet.jpg";
import smoothie from "@/assets/smoothie.jpg";
import story from "@/assets/story.jpg";

export type GalleryCategory = "Food" | "Drinks" | "Restaurant" | "Breakfast" | "Desserts";

export const GALLERY: { src: string; alt: string; categories: GalleryCategory[] }[] = [
  { src: hero, alt: "Cafeteria Nigeria dining room at golden hour", categories: ["Restaurant"] },
  { src: pancakes, alt: "Berry Bliss Pancakes", categories: ["Food", "Breakfast"] },
  { src: benedict, alt: "Egg Benedict on Texas toast", categories: ["Food", "Breakfast"] },
  { src: story, alt: "Chef plating brunch at Cafeteria Nigeria", categories: ["Restaurant"] },
  { src: chickenWaffle, alt: "Chicago Style Chicken & Waffle", categories: ["Food", "Breakfast"] },
  { src: acai, alt: "Açaí Berry Bowl", categories: ["Food", "Breakfast"] },
  { src: skillet, alt: "Pulled Beef Skillet", categories: ["Food", "Breakfast"] },
  { src: panini, alt: "Prawn and pesto panini", categories: ["Food"] },
  { src: dessert, alt: "Waffle Sundae", categories: ["Desserts", "Food"] },
  { src: bubbleTea, alt: "Bubble tea selection", categories: ["Drinks"] },
  { src: coffee, alt: "Cappuccino with latte art", categories: ["Drinks"] },
  { src: smoothie, alt: "Fresh fruit smoothies", categories: ["Drinks"] },
];

const FILTERS: ("All" | GalleryCategory)[] = [
  "All",
  "Food",
  "Drinks",
  "Restaurant",
  "Breakfast",
  "Desserts",
];

export function GalleryGrid() {
  const [filter, setFilter] = useState<"All" | GalleryCategory>("All");
  const [active, setActive] = useState<number | null>(null);

  const items = GALLERY.filter((g) => filter === "All" || g.categories.includes(filter));

  useEffect(() => {
    if (active === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
      if (e.key === "ArrowRight") setActive((i) => ((i ?? 0) + 1) % items.length);
      if (e.key === "ArrowLeft") setActive((i) => ((i ?? 0) - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, items.length]);

  return (
    <div>
      <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 pb-2 sm:mx-0 sm:justify-center sm:px-0">
        {FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => {
              setFilter(f);
              setActive(null);
            }}
            className={cn(
              "shrink-0 border px-4 py-2 text-[0.65rem] tracking-[0.2em] uppercase transition-colors",
              filter === f
                ? "border-gold bg-gold text-gold-foreground"
                : "border-border text-muted-foreground hover:border-foreground/40",
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
        {items.map((img, i) => (
          <button
            key={img.src + img.alt}
            type="button"
            onClick={() => setActive(i)}
            className="group block w-full overflow-hidden border border-border"
            aria-label={`Open ${img.alt}`}
          >
            <img
              src={img.src}
              alt={img.alt}
              loading="lazy"
              className="w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.05]"
            />
          </button>
        ))}
      </div>

      {active !== null && items[active] ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={items[active].alt}
          className="fixed inset-0 z-[60] flex items-center justify-center bg-charcoal/95 p-4 backdrop-blur"
          onClick={() => setActive(null)}
        >
          <button
            type="button"
            onClick={() => setActive(null)}
            aria-label="Close image"
            className="absolute top-5 right-5 grid size-11 place-items-center border border-gold/40 text-gold"
          >
            <X className="size-5" />
          </button>
          <figure className="max-h-full max-w-5xl" onClick={(e) => e.stopPropagation()}>
            <img
              src={items[active].src}
              alt={items[active].alt}
              className="max-h-[78vh] w-auto object-contain"
            />
            <figcaption className="mt-4 text-center text-xs tracking-[0.2em] text-charcoal-foreground/70 uppercase">
              {items[active].alt}
            </figcaption>
          </figure>
        </div>
      ) : null}
    </div>
  );
}
