import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Reveal, SectionHeading } from "@/components/site/Reveal";
import { RESTAURANT } from "@/lib/restaurant";
import story from "@/assets/story.jpg";
import hero from "@/assets/hero.jpg";
import coffee from "@/assets/coffee.jpg";

const TITLE = "Our Story | Cafeteria Nigeria, Victoria Island Lagos";
const DESCRIPTION =
  "How Cafeteria Nigeria began in 2018 — a Victoria Island kitchen built on carefully prepared food and locally sourced ingredients.";

export const Route = createFileRoute("/our-story")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "article" },
      { property: "og:url", content: "/our-story" },
    ],
    links: [{ rel: "canonical", href: "/our-story" }],
  }),
  component: StoryPage,
});

function StoryPage() {
  return (
    <>
      <section className="relative flex min-h-[46svh] items-center justify-center overflow-hidden">
        <img
          src={hero}
          alt="Cafeteria Nigeria dining room"
          width={1920}
          height={1280}
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/70" />
        <div className="relative z-10 px-5 py-20 text-center text-charcoal-foreground">
          <p className="script-accent">Since {RESTAURANT.established}</p>
          <h1 className="mt-3 font-display text-4xl tracking-[0.06em] uppercase sm:text-5xl">
            Our Story
          </h1>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
          <Reveal>
            <img
              src={story}
              alt="Chef preparing brunch at Cafeteria Nigeria"
              loading="lazy"
              width={1200}
              height={1408}
              className="w-full object-cover"
            />
          </Reveal>
          <Reveal delay={100}>
            <SectionHeading eyebrow="Our Story" title="A Lagos kitchen, since 2018" align="left" />
            <div className="mt-6 space-y-5 text-[0.95rem] leading-relaxed text-muted-foreground">
              <p>
                Cafeteria Nigeria opened its doors in {RESTAURANT.established} on Akin Adesola
                Street, Victoria Island. The idea was straightforward — a warm room, an all-day
                kitchen, and food prepared properly, whether that means a stack of fluffy pancakes
                at 8am or a pesto panini at 8pm.
              </p>
              <p>
                Our menu was built around the things people actually want to eat together: batters
                and toasts, benedicts, skillets, fruit bowls, salads and paninis, and a long list of
                smoothies, juices, coffee and bubble tea to go with them.
              </p>
              <p>
                We source locally wherever possible and prepare to order, which is why the kitchen
                keeps the menu focused and the plates consistent. Nothing complicated — just quality
                and care, every service.
              </p>
              <p className="script-accent">Good food. Great moments.</p>
            </div>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild variant="charcoal" size="xl">
                <Link to="/menu">View the Menu</Link>
              </Button>
              <Button asChild variant="inkOutline" size="xl">
                <Link to="/visit-us">Visit Us</Link>
              </Button>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary/60 py-20 lg:py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="In the room"
              title="All day, every day"
              align="left"
              intro="Breakfast from 8am, brunch through the afternoon, lunch and dinner into the night — and 24 hours on Fridays and Saturdays."
            />
          </Reveal>
          <Reveal delay={120}>
            <img
              src={coffee}
              alt="Cappuccino served at Cafeteria Nigeria"
              loading="lazy"
              width={1024}
              height={1024}
              className="w-full object-cover"
            />
          </Reveal>
        </div>
      </section>
    </>
  );
}
