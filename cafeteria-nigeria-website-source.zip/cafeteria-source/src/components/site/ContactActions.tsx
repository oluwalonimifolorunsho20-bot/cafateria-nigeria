import { MapPin, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  DEFAULT_WHATSAPP_MESSAGE,
  DIRECTIONS_URL,
  telHref,
  whatsappHref,
} from "@/lib/restaurant";

export function ContactActions({
  className,
  tone = "light",
}: {
  className?: string;
  tone?: "light" | "dark";
}) {
  return (
    <div className={cn("flex flex-wrap gap-3", className)}>
      <Button asChild variant="gold" size="xl">
        <a href={telHref}>
          <Phone /> Call Us
        </a>
      </Button>
      <Button asChild variant={tone === "dark" ? "goldOutline" : "inkOutline"} size="xl">
        <a href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)} target="_blank" rel="noreferrer">
          <MessageCircle /> Chat on WhatsApp
        </a>
      </Button>
      <Button asChild variant={tone === "dark" ? "goldOutline" : "inkOutline"} size="xl">
        <a href={DIRECTIONS_URL} target="_blank" rel="noreferrer">
          <MapPin /> Get Directions
        </a>
      </Button>
    </div>
  );
}

export function MobileActionBar() {
  return (
    <nav
      aria-label="Quick contact"
      className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-3 border-t border-gold/25 bg-charcoal/95 backdrop-blur md:hidden"
    >
      <a
        href={telHref}
        className="flex min-h-14 flex-col items-center justify-center gap-1 text-[0.65rem] tracking-[0.2em] text-charcoal-foreground uppercase"
      >
        <Phone className="size-4 text-gold" /> Call
      </a>
      <a
        href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)}
        target="_blank"
        rel="noreferrer"
        className="flex min-h-14 flex-col items-center justify-center gap-1 border-x border-gold/20 text-[0.65rem] tracking-[0.2em] text-charcoal-foreground uppercase"
      >
        <MessageCircle className="size-4 text-gold" /> WhatsApp
      </a>
      <a
        href={DIRECTIONS_URL}
        target="_blank"
        rel="noreferrer"
        className="flex min-h-14 flex-col items-center justify-center gap-1 text-[0.65rem] tracking-[0.2em] text-charcoal-foreground uppercase"
      >
        <MapPin className="size-4 text-gold" /> Directions
      </a>
    </nav>
  );
}
