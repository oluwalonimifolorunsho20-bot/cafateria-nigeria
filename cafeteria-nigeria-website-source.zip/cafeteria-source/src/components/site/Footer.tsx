import { Link } from "@tanstack/react-router";
import { Instagram } from "lucide-react";
import { NAV_LINKS } from "@/components/site/Nav";
import { OPENING_HOURS, RESTAURANT } from "@/lib/restaurant";

export function Footer() {
  return (
    <footer className="bg-charcoal pb-20 text-charcoal-foreground md:pb-0">
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <h2 className="text-2xl tracking-[0.24em] uppercase">Cafeteria Nigeria</h2>
            <p className="script-accent mt-2">Good food, great moments</p>
            <p className="mt-5 text-sm leading-relaxed text-charcoal-foreground/70">
              {RESTAURANT.address.line1}
              <br />
              {RESTAURANT.address.line2}
            </p>
            <a
              href={`https://www.instagram.com/${RESTAURANT.instagramHandle.replace("@", "")}`}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 text-sm text-gold transition-opacity hover:opacity-75"
            >
              <Instagram className="size-4" /> {RESTAURANT.instagramHandle}
            </a>
          </div>

          <div>
            <p className="eyebrow">Explore</p>
            <ul className="mt-5 space-y-3">
              {NAV_LINKS.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-charcoal-foreground/75 transition-colors hover:text-gold"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow">Opening Hours</p>
            <ul className="mt-5 space-y-2 text-sm">
              {OPENING_HOURS.map((h) => (
                <li key={h.label} className="flex justify-between gap-4">
                  <span className="text-charcoal-foreground/60">{h.label}</span>
                  <span className="text-charcoal-foreground/90">{h.display}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-charcoal-foreground/15 pt-6 text-center text-xs tracking-[0.18em] text-charcoal-foreground/50 uppercase">
          © {RESTAURANT.name}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
