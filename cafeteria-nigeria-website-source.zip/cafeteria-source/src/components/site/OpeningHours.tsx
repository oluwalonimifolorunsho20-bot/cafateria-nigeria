import { useEffect, useState } from "react";
import { isOpenNow, lagosNow, OPENING_HOURS } from "@/lib/restaurant";
import { cn } from "@/lib/utils";

export function OpenStatusBadge({ className }: { className?: string }) {
  const [state, setState] = useState<boolean | null>(null);

  useEffect(() => {
    setState(isOpenNow());
    const id = setInterval(() => setState(isOpenNow()), 60_000);
    return () => clearInterval(id);
  }, []);

  if (state === null) return null;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 border px-3 py-1.5 text-[0.6rem] tracking-[0.24em] uppercase",
        state ? "border-gold/60 text-gold" : "border-border text-muted-foreground",
        className,
      )}
    >
      <span
        className={cn("size-1.5 rounded-full", state ? "animate-pulse bg-gold" : "bg-muted-foreground")}
      />
      {state ? "Open Now" : "Closed Now"}
    </span>
  );
}

export function OpeningHoursTable({ tone = "dark" }: { tone?: "light" | "dark" }) {
  const [today, setToday] = useState<number | null>(null);
  useEffect(() => setToday(lagosNow().day), []);

  return (
    <ul className="divide-y divide-current/10">
      {OPENING_HOURS.map((h) => {
        const current = today === h.day;
        return (
          <li
            key={h.label}
            className={cn(
              "flex items-center justify-between gap-6 px-4 py-4 transition-colors",
              current && (tone === "dark" ? "bg-gold/10" : "bg-secondary"),
            )}
          >
            <span
              className={cn(
                "text-sm tracking-[0.16em] uppercase",
                current
                  ? "text-gold"
                  : tone === "dark"
                    ? "text-charcoal-foreground/60"
                    : "text-muted-foreground",
              )}
            >
              {h.label}
              {current ? " · Today" : ""}
            </span>
            <span
              className={cn(
                "font-display text-base",
                tone === "dark" ? "text-charcoal-foreground" : "text-foreground",
              )}
            >
              {h.display}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
