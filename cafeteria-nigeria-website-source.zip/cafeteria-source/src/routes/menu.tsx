import { createFileRoute } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { MenuItemCard } from "@/components/site/MenuItemCard";
import { Reveal, SectionHeading } from "@/components/site/Reveal";
import { BubbleTeaSpot, SmoothieBuilder } from "@/components/site/MenuBuilders";
import { CATEGORIES, MENU, formatPrice, type MenuItem } from "@/lib/menu";
import { cn } from "@/lib/utils";

const TITLE = "Menu | Cafeteria Nigeria, Victoria Island Lagos";
const DESCRIPTION =
  "Browse the full Cafeteria Nigeria menu — pancakes, benedicts, skillets, salads, paninis, desserts, smoothies, coffee, bubble tea and milkshakes with Naira prices.";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: "/menu" },
    ],
    links: [{ rel: "canonical", href: "/menu" }],
  }),
  component: MenuPage,
});

const FILTERS = [
  "All",
  "Breakfast",
  "Lunch & Dinner",
  "Drinks",
  "Desserts",
  "Vegetarian",
  "Vegan",
  "House Favorites",
] as const;
type Filter = (typeof FILTERS)[number];

function matchesFilter(item: MenuItem, filter: Filter) {
  switch (filter) {
    case "All":
      return true;
    case "Vegetarian":
    case "Vegan":
      return (item.dietary ?? []).includes(filter);
    case "House Favorites":
      return Boolean(item.featured);
    default:
      return item.group === filter;
  }
}

function MenuPage() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("All");
  const [category, setCategory] = useState<string | null>(null);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase().slice(0, 80);
    return MENU.filter((item) => {
      if (!matchesFilter(item, filter)) return false;
      if (category && item.category !== category) return false;
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        (item.description ?? "").toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
    });
  }, [query, filter, category]);

  const grouped = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    for (const item of results) {
      const list = map.get(item.category) ?? [];
      list.push(item);
      map.set(item.category, list);
    }
    return CATEGORIES.filter((c) => map.has(c.label)).map((c) => ({
      category: c,
      items: map.get(c.label)!,
    }));
  }, [results]);

  return (
    <>
      <section className="border-b border-border bg-secondary/50 py-14 lg:py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            script="The full"
            eyebrow="Digital Menu"
            title="Our Menu"
            intro="Search or filter to find exactly what you're after. Prices are in Naira and every dish can be enquired about directly on WhatsApp."
          />

          <div className="mx-auto mt-10 max-w-xl">
            <div className="relative">
              <Search className="absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                maxLength={80}
                placeholder="Search the menu..."
                aria-label="Search the menu"
                className="h-12 rounded-none border-border bg-background pr-11 pl-11"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Clear search"
                  className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="size-4" />
                </button>
              ) : null}
            </div>
          </div>

          <div className="no-scrollbar -mx-5 mt-6 flex gap-2 overflow-x-auto px-5 sm:mx-0 sm:flex-wrap sm:justify-center sm:px-0">
            {FILTERS.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => {
                  setFilter(f);
                  setCategory(null);
                }}
                className={cn(
                  "shrink-0 border px-4 py-2 text-[0.65rem] tracking-[0.2em] uppercase transition-colors",
                  filter === f
                    ? "border-charcoal bg-charcoal text-charcoal-foreground"
                    : "border-border text-muted-foreground hover:border-foreground/40",
                )}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="no-scrollbar -mx-5 mt-3 flex gap-2 overflow-x-auto px-5 sm:mx-0 sm:flex-wrap sm:justify-center sm:px-0">
            <button
              type="button"
              onClick={() => setCategory(null)}
              className={cn(
                "shrink-0 px-3 py-2 text-[0.65rem] tracking-[0.18em] uppercase transition-colors",
                category === null ? "text-gold underline underline-offset-4" : "text-muted-foreground hover:text-foreground",
              )}
            >
              All Categories
            </button>
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategory(c.label)}
                className={cn(
                  "shrink-0 px-3 py-2 text-[0.65rem] tracking-[0.18em] uppercase transition-colors",
                  category === c.label
                    ? "text-gold underline underline-offset-4"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {c.label}
              </button>
            ))}
          </div>

          <p className="mt-6 text-center text-xs tracking-[0.2em] text-muted-foreground uppercase">
            {results.length} {results.length === 1 ? "item" : "items"}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-20">
        {grouped.length === 0 ? (
          <p className="py-16 text-center text-muted-foreground">
            Nothing matched “{query}”. Try another dish or clear the filters.
          </p>
        ) : (
          <div className="space-y-16">
            {grouped.map(({ category: cat, items }) => (
              <div key={cat.id} id={cat.id}>
                <div className="flex items-end justify-between gap-6 border-b border-border pb-4">
                  <h2 className="text-2xl tracking-[0.12em] uppercase sm:text-3xl">{cat.label}</h2>
                  <span className="text-[0.6rem] tracking-[0.2em] text-muted-foreground uppercase">
                    {cat.group}
                  </span>
                </div>

                {items.some((i) => i.image) ? (
                  <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {items
                      .filter((i) => i.image)
                      .map((item, i) => (
                        <Reveal key={item.id} delay={i * 60}>
                          <MenuItemCard item={item} />
                        </Reveal>
                      ))}
                  </div>
                ) : null}

                {items.some((i) => !i.image) ? (
                  <ul className="mt-8 grid gap-x-12 gap-y-6 sm:grid-cols-2">
                    {items
                      .filter((i) => !i.image)
                      .map((item) => (
                        <li key={item.id} className="group">
                          <div className="flex items-baseline gap-3">
                            <span className="text-base">{item.name}</span>
                            <span className="h-px flex-1 border-b border-dashed border-border" />
                            <span
                              className={cn(
                                "shrink-0 font-display",
                                item.price === null
                                  ? "text-[0.6rem] tracking-[0.16em] text-muted-foreground uppercase"
                                  : "text-gold",
                              )}
                            >
                              {formatPrice(item.price)}
                            </span>
                          </div>
                          {item.description ? (
                            <p className="mt-1 max-w-prose text-sm leading-relaxed text-muted-foreground">
                              {item.description}
                            </p>
                          ) : null}
                        </li>
                      ))}
                  </ul>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </section>

      <SmoothieBuilder />
      <BubbleTeaSpot />
    </>
  );
}
