import { Link } from "@tanstack/react-router";
import { Menu as MenuIcon, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const NAV_LINKS = [
  { to: "/", label: "Home" },
  { to: "/our-story", label: "Our Story" },
  { to: "/menu", label: "Menu" },
  { to: "/gallery", label: "Gallery" },
  { to: "/visit-us", label: "Visit Us" },
  { to: "/contact", label: "Contact" },
] as const;

export function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b transition-colors duration-500",
        scrolled || open
          ? "border-border/70 bg-background/95 backdrop-blur"
          : "border-transparent bg-background/70 backdrop-blur-sm",
      )}
    >
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 lg:px-8">
        <Link to="/" className="min-w-0" onClick={() => setOpen(false)}>
          <span className="block font-display text-lg leading-none tracking-[0.28em] uppercase">
            Cafeteria
          </span>
          <span className="mt-1 block text-[0.55rem] tracking-[0.42em] text-gold uppercase">
            Nigeria · Lagos
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Main">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{ className: "text-foreground after:w-full" }}
              inactiveProps={{ className: "text-muted-foreground" }}
              className="relative text-[0.7rem] tracking-[0.22em] uppercase transition-colors after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-gold after:transition-all after:duration-300 hover:text-foreground hover:after:w-full"
            >
              {l.label}
            </Link>
          ))}
          <Button asChild variant="gold" size="default" className="ml-2">
            <Link to="/menu">View Menu</Link>
          </Button>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          className="grid size-11 shrink-0 place-items-center border border-border md:hidden"
        >
          {open ? <X className="size-5" /> : <MenuIcon className="size-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-border bg-background md:hidden">
          <nav className="flex flex-col px-5 py-2" aria-label="Mobile">
            {NAV_LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="border-b border-border/60 py-4 text-sm tracking-[0.2em] uppercase last:border-0"
              >
                {l.label}
              </Link>
            ))}
            <Button asChild variant="gold" size="xl" className="my-4">
              <Link to="/menu" onClick={() => setOpen(false)}>
                View Menu
              </Link>
            </Button>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
