import { MessageCircle } from "lucide-react";
import { dishEnquiryHref } from "@/lib/restaurant";
import { formatPrice, type MenuItem } from "@/lib/menu";
import { cn } from "@/lib/utils";

export function MenuItemCard({ item }: { item: MenuItem }) {
  return (
    <article className="card-elegant group flex flex-col overflow-hidden">
      {item.image ? (
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={item.image}
            alt={item.name}
            loading="lazy"
            width={1024}
            height={768}
            className="size-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]"
          />
          {item.featured ? (
            <span className="absolute top-3 left-3 bg-gold px-3 py-1 text-[0.6rem] tracking-[0.22em] text-gold-foreground uppercase">
              House Favorite
            </span>
          ) : null}
        </div>
      ) : null}

      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-baseline justify-between gap-4 border-b border-dashed border-border pb-3">
          <h3 className="text-lg leading-snug">{item.name}</h3>
          <span
            className={cn(
              "shrink-0 font-display text-base",
              item.price === null ? "text-xs tracking-[0.14em] text-muted-foreground uppercase" : "text-gold",
            )}
          >
            {formatPrice(item.price)}
          </span>
        </div>

        {item.description ? (
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
        ) : null}

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="text-[0.6rem] tracking-[0.2em] text-muted-foreground uppercase">
            {item.category}
          </span>
          {(item.dietary ?? []).map((tag) => (
            <span
              key={tag}
              className="border border-gold/40 px-2 py-0.5 text-[0.6rem] tracking-[0.14em] text-foreground/70 uppercase"
            >
              {tag}
            </span>
          ))}
          {item.available === false ? (
            <span className="bg-muted px-2 py-0.5 text-[0.6rem] tracking-[0.14em] text-muted-foreground uppercase">
              Unavailable today
            </span>
          ) : null}
        </div>

        <a
          href={dishEnquiryHref(item.name)}
          target="_blank"
          rel="noreferrer"
          className="mt-5 inline-flex items-center gap-2 self-start text-[0.65rem] tracking-[0.22em] text-foreground/70 uppercase transition-colors hover:text-gold"
        >
          <MessageCircle className="size-3.5" /> Ask About This Dish
        </a>
      </div>
    </article>
  );
}
