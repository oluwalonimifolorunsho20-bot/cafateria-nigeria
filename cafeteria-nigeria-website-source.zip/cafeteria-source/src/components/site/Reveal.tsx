import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "li" | "article";
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.05 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      ref={ref as never}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
      className={cn("reveal", shown && "reveal-in", className)}
    >
      {children}
    </Tag>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  script,
  intro,
  tone = "light",
  align = "center",
}: {
  eyebrow?: string;
  title: string;
  script?: string;
  intro?: string;
  tone?: "light" | "dark";
  align?: "center" | "left";
}) {
  return (
    <div
      className={cn(
        "mx-auto max-w-2xl",
        align === "center" ? "text-center" : "mx-0 text-left",
        tone === "dark" && "text-charcoal-foreground",
      )}
    >
      {script ? <p className="script-accent mb-1">{script}</p> : null}
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <h2 className="mt-3 text-3xl leading-tight sm:text-4xl md:text-[2.75rem]">{title}</h2>
      <div className={cn("mt-5", align === "center" ? "rule-gold" : "")}>
        <span className="inline-block h-1.5 w-1.5 rotate-45 bg-gold" />
      </div>
      {intro ? (
        <p
          className={cn(
            "mt-5 text-[0.95rem] leading-relaxed",
            tone === "dark" ? "text-charcoal-foreground/70" : "text-muted-foreground",
          )}
        >
          {intro}
        </p>
      ) : null}
    </div>
  );
}
