/**
 * Cafeteria Nigeria — editable business information.
 * Update the values in this file to change contact details site-wide.
 */

// The restaurant phone / WhatsApp number. Full international format.
// TODO: replace with the exact number printed on the restaurant's menu.
export const RESTAURANT_PHONE_NUMBER = "+2340000000000";

// Set to false while the number above is still a placeholder-free real number check.
export const PHONE_NUMBER_CONFIRMED = false;

export const RESTAURANT = {
  name: "Cafeteria Nigeria",
  tagline: "Good Food. Great Moments.",
  established: 2018,
  address: {
    line1: "16B Akin Adesola Street",
    line2: "Victoria Island, Lagos 106104",
    country: "Lagos, Nigeria",
    full: "16B Akin Adesola Street, Victoria Island, Lagos 106104, Lagos, Nigeria",
  },
  instagramHandle: "@cafeteria_ng",
  currency: "₦",
} as const;

export const MAPS_QUERY = encodeURIComponent(
  `${RESTAURANT.name}, ${RESTAURANT.address.full}`,
);

export const DIRECTIONS_URL = `https://www.google.com/maps/dir/?api=1&destination=${MAPS_QUERY}`;
export const MAP_EMBED_URL = `https://maps.google.com/maps?q=${MAPS_QUERY}&z=16&output=embed`;

export const telHref = `tel:${RESTAURANT_PHONE_NUMBER}`;

export function whatsappHref(message: string) {
  const digits = RESTAURANT_PHONE_NUMBER.replace(/[^\d]/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

export const DEFAULT_WHATSAPP_MESSAGE =
  "Hello Cafeteria Nigeria, I found your website and I'd like to make an enquiry.";

export function dishEnquiryHref(dish: string) {
  return whatsappHref(`Hello Cafeteria Nigeria, I'd like to ask about the ${dish}.`);
}

export type OpeningHour = {
  /** 0 = Sunday, matching Date#getDay() */
  day: number;
  label: string;
  display: string;
  /** minutes from midnight; null when open 24 hours */
  open: number | null;
  close: number | null;
  allDay: boolean;
};

export const OPENING_HOURS: OpeningHour[] = [
  { day: 1, label: "Monday", display: "8:00 AM – 10:00 PM", open: 480, close: 1320, allDay: false },
  { day: 2, label: "Tuesday", display: "8:00 AM – 10:00 PM", open: 480, close: 1320, allDay: false },
  {
    day: 3,
    label: "Wednesday",
    display: "8:00 AM – 10:00 PM",
    open: 480,
    close: 1320,
    allDay: false,
  },
  {
    day: 4,
    label: "Thursday",
    display: "8:00 AM – 10:00 PM",
    open: 480,
    close: 1320,
    allDay: false,
  },
  { day: 5, label: "Friday", display: "Open 24 hours", open: null, close: null, allDay: true },
  { day: 6, label: "Saturday", display: "Open 24 hours", open: null, close: null, allDay: true },
  { day: 0, label: "Sunday", display: "8:00 AM – 10:00 PM", open: 480, close: 1320, allDay: false },
];

/** Current Lagos (UTC+1) date parts, independent of the visitor's timezone. */
export function lagosNow() {
  const now = new Date();
  const lagos = new Date(now.getTime() + (now.getTimezoneOffset() + 60) * 60_000);
  return { day: lagos.getDay(), minutes: lagos.getHours() * 60 + lagos.getMinutes() };
}

export function isOpenNow(): boolean {
  const { day, minutes } = lagosNow();
  const today = OPENING_HOURS.find((h) => h.day === day);
  if (!today) return false;
  if (today.allDay) return true;
  return minutes >= (today.open ?? 0) && minutes < (today.close ?? 0);
}
