import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronDown, MapPin, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ContactActions } from "@/components/site/ContactActions";
import { MenuItemCard } from "@/components/site/MenuItemCard";
import { OpenStatusBadge, OpeningHoursTable } from "@/components/site/OpeningHours";
import { Reveal, SectionHeading } from "@/components/site/Reveal";
import { FEATURED } from "@/lib/menu";
import {
  DEFAULT_WHATSAPP_MESSAGE,
  RESTAURANT,
  whatsappHref,
} from "@/lib/restaurant";
import hero from "@/assets/hero.jpg";
import story from "@/assets/story.jpg";

const TITLE = "Cafeteria Nigeria | Restaurant in Victoria Island, Lagos";
const DESCRIPTION =
  "Discover Cafeteria Nigeria in Victoria Island, Lagos — breakfast, brunch, lunch, dinner, smoothies, coffee, desserts and more.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Restaurant",
          name: RESTAURANT.name,
          servesCuisine: ["Breakfast", "Brunch", "Continental"],
          priceRange: "₦₦",
          address: {
            "@type": "PostalAddress",
            streetAddress: RESTAURANT.address.line1,
            addressLocality: "Victoria Island, Lagos",
            postalCode: "106104",
            addressRegion: "Lagos",
            addressCountry: "NG",
          },
          openingHoursSpecification: [
            {
              "@type": "OpeningHoursSpecification",
              dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Sunday"],
              opens: "08:00",
              closes: "22:00",
            },
            {
              "@type": "OpeningHoursSpecification",
              dayOfWeek: ["Friday", "Saturday"],
              opens: "00:00",
              closes: "23:59",
            },
          ],
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      <section className="relative flex min-h-[92svh] items-center justify-center overflow-hidden">
        <img
          src={hero}
          alt="Dining room at Cafeteria Nigeria, Victoria Island"
          width={1920}
          height={1280}
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/62" />
        <div className="relative z-10 mx-auto max-w-3xl px-5 py-24 text-center text-charcoal-foreground">
          <p className="text-[0.65rem] tracking-[0.5em] text-gold uppercase">Cafeteria Nigeria</p>
          <h1 className="mt-6 font-display text-4xl leading-[1.05] sm:text-6xl md:text-7xl">
            Good Food.
            <br />
            Great Moments.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-sm leading-relaxed text-charcoal-foreground/80 sm:text-base">
            A premium dining experience in the heart of Victoria Island, Lagos.
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Button asChild variant="gold" size="xl">
              <Link to="/menu">View Menu</Link>
            </Button>
            <Button asChild variant="goldOutline" size="xl">
              <a href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)} target="_blank" rel="noreferrer">
                <MessageCircle /> Chat on WhatsApp
              </a>
            </Button>
          </div>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <span className="inline-flex items-center gap-2 text-xs tracking-[0.24em] uppercase">
              <MapPin className="size-4 text-gold" /> Victoria Island, Lagos
            </span>
            <OpenStatusBadge />
          </div>
        </div>
        <a
          href="#story"
          aria-label="Scroll to our story"
          className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-gold"
        >
          <ChevronDown className="size-7 animate-bounce" />
        </a>
      </section>

      <section id="story" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <Reveal className="relative">
            <img
              src={story}
              alt="Chef plating a dish at Cafeteria Nigeria"
              loading="lazy"
              width={1200}
              height={1408}
              className="w-full object-cover"
            />
            <span className="absolute -right-3 -bottom-3 hidden border border-gold/60 px-5 py-3 font-display text-sm tracking-[0.2em] text-gold uppercase sm:block">
              Est. {RESTAURANT.established}
            </span>
          </Reveal>
          <Reveal delay={120}>
            <SectionHeading
              script="Since 2018"
              eyebrow="Our Story"
              title="Our Story"
              align="left"
            />
            <div className="mt-6 space-y-4 text-[0.95rem] leading-relaxed text-muted-foreground">
              <p>
                Cafeteria Nigeria was established in {RESTAURANT.established} with one simple
                intention: to give Lagos a dining room worth returning to. Every plate is prepared
                with care, from our stacks and skillets in the morning to paninis, salads and
                sundaes later in the day.
              </p>
              <p>
                We cook with locally sourced ingredients wherever we can, and we keep our kitchen
                focused on quality over shortcuts — a quiet, consistent standard our regulars in
                Victoria Island have come to expect.
              </p>
            </div>
            <div className="mt-8">
              <Button asChild variant="inkOutline" size="xl">
                <Link to="/our-story">Read More</Link>
              </Button>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary/60 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <SectionHeading
              script="A taste of"
              eyebrow="Featured"
              title="A Taste of Cafeteria"
              intro="A handful of the plates our guests keep coming back for."
            />
          </Reveal>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURED.map((item, i) => (
              <Reveal key={item.id} delay={i * 70}>
                <MenuItemCard item={item} />
              </Reveal>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button asChild variant="charcoal" size="xl">
              <Link to="/menu">Explore Full Menu</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="bg-charcoal py-20 text-charcoal-foreground lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="Opening Hours"
              title="Always Time For Brunch"
              tone="dark"
              align="left"
            />
            <div className="mt-6">
              <OpenStatusBadge />
            </div>
            <div className="mt-8 border border-charcoal-foreground/15">
              <OpeningHoursTable tone="dark" />
            </div>
          </Reveal>
          <Reveal delay={120}>
            <SectionHeading eyebrow="Come Find Us" title="Come Find Us" tone="dark" align="left" />
            <p className="mt-6 font-display text-2xl leading-relaxed">
              {RESTAURANT.address.line1}
              <br />
              {RESTAURANT.address.line2}
            </p>
            <ContactActions className="mt-8" tone="dark" />
            <div className="mt-8">
              <Button asChild variant="goldOutline" size="xl">
                <Link to="/visit-us">Reserve a Table</Link>
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
