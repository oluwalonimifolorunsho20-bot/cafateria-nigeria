import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { whatsappHref } from "@/lib/restaurant";

const schema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(80),
  phone: z
    .string()
    .trim()
    .min(7, "Please enter a reachable phone number")
    .max(20)
    .regex(/^[+\d][\d\s-]*$/, "Use digits, spaces or +"),
  email: z.string().trim().email("Enter a valid email").max(160).or(z.literal("")),
  date: z.string().min(1, "Choose a date"),
  time: z.string().min(1, "Choose a time"),
  guests: z.string().min(1, "How many guests?"),
  request: z.string().trim().max(500).optional(),
});

type Values = z.infer<typeof schema>;
const empty: Values = {
  name: "",
  phone: "",
  email: "",
  date: "",
  time: "",
  guests: "2",
  request: "",
};

export function ReservationForm() {
  const [values, setValues] = useState<Values>(empty);
  const [errors, setErrors] = useState<Partial<Record<keyof Values, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof Values) => (e: { target: { value: string } }) =>
    setValues((v) => ({ ...v, [key]: e.target.value }));

  const message = () =>
    [
      "Hello Cafeteria Nigeria, I'd like to request a reservation.",
      `Name: ${values.name || "—"}`,
      `Phone: ${values.phone || "—"}`,
      values.email ? `Email: ${values.email}` : null,
      `Date: ${values.date || "—"}`,
      `Time: ${values.time || "—"}`,
      `Guests: ${values.guests || "—"}`,
      values.request ? `Special request: ${values.request}` : null,
    ]
      .filter(Boolean)
      .join("\n");

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      const next: Partial<Record<keyof Values, string>> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof Values;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      setSubmitted(false);
      return;
    }
    setErrors({});
    setSubmitted(true);
  }

  const field = (
    key: keyof Values,
    label: string,
    type = "text",
    props: Record<string, unknown> = {},
  ) => (
    <div>
      <Label htmlFor={key} className="text-[0.65rem] tracking-[0.2em] uppercase">
        {label}
      </Label>
      <Input
        id={key}
        type={type}
        value={values[key] ?? ""}
        onChange={set(key)}
        className="mt-2 h-11 rounded-none border-border bg-background"
        {...props}
      />
      {errors[key] ? <p className="mt-1 text-xs text-destructive">{errors[key]}</p> : null}
    </div>
  );

  return (
    <form onSubmit={onSubmit} className="card-elegant p-6 sm:p-8" noValidate>
      <div className="grid gap-5 sm:grid-cols-2">
        {field("name", "Name")}
        {field("phone", "Phone Number", "tel")}
        {field("email", "Email (optional)", "email")}
        {field("guests", "Number of Guests", "number", { min: 1, max: 40 })}
        {field("date", "Date", "date")}
        {field("time", "Time", "time")}
      </div>

      <div className="mt-5">
        <Label htmlFor="request" className="text-[0.65rem] tracking-[0.2em] uppercase">
          Special Request
        </Label>
        <Textarea
          id="request"
          value={values.request ?? ""}
          onChange={set("request")}
          rows={4}
          maxLength={500}
          className="mt-2 rounded-none border-border bg-background"
          placeholder="Birthday, window seat, high chair…"
        />
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Button type="submit" variant="charcoal" size="xl">
          Request a Reservation
        </Button>
        <Button asChild variant="inkOutline" size="xl">
          <a href={whatsappHref(message())} target="_blank" rel="noreferrer">
            <MessageCircle /> Book via WhatsApp
          </a>
        </Button>
      </div>

      {submitted ? (
        <p
          role="status"
          className="mt-5 border border-gold/50 bg-gold/10 p-4 text-sm leading-relaxed"
        >
          Reservation request received. The restaurant will confirm your booking. For an instant
          reply, send the same details on WhatsApp.
        </p>
      ) : null}
    </form>
  );
}
