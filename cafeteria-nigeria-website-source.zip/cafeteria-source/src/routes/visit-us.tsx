import { createFileRoute } from "@tanstack/react-router";
import { ContactActions } from "@/components/site/ContactActions";
import { OpenStatusBadge, OpeningHoursTable } from "@/components/site/OpeningHours";
import { ReservationForm } from "@/components/site/ReservationForm";
import { Reveal, SectionHeading } from "@/components/site/Reveal";
import { MAP_EMBED_URL, RESTAURANT } from "@/lib/restaurant";

const TITLE = "Visit Us | Cafeteria Nigeria, Victoria Island Lagos";
const DESCRIPTION =
  "Find Cafeteria Nigeria at 16B Akin Adesola Street, Victoria Island, Lagos. Opening hours, directions and table reservation requests.";

export const Route = createFileRoute("/visit-us")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: "/visit-us" },
    ],
    links: [{ rel: "canonical", href: "/visit-us" }],
  }),
  component: VisitPage,
});

function VisitPage() {
  return (
    <>
      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
        <SectionHeading
          script="Come find us"
          eyebrow="Visit Us"
          title="Come Find Us"
          intro={RESTAURANT.address.full}
        />

        <div className="mt-12 grid gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="border border-border">
              <iframe
                title="Map showing Cafeteria Nigeria, Victoria Island, Lagos"
                src={MAP_EMBED_URL}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-[380px] w-full"
              />
            </div>
            <ContactActions className="mt-6" />
          </Reveal>

          <Reveal delay={120}>
            <div className="flex items-center gap-4">
              <h2 className="text-2xl tracking-[0.12em] uppercase">Opening Hours</h2>
              <OpenStatusBadge />
            </div>
            <div className="mt-6 border border-border bg-card">
              <OpeningHoursTable tone="light" />
            </div>
            <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
              Open 24 hours on Fridays and Saturdays — late brunch, late dinner, or coffee at
              midnight.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary/60 py-16 lg:py-24">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <SectionHeading
            eyebrow="Reservations"
            title="Request a Table"
            intro="Send us your details and the restaurant will confirm your booking. For an instant response, book on WhatsApp."
          />
          <div className="mt-10">
            <ReservationForm />
          </div>
        </div>
      </section>
    </>
  );
}
