import { createFileRoute } from "@tanstack/react-router";
import { Instagram } from "lucide-react";
import { GalleryGrid } from "@/components/site/GalleryGrid";
import { SectionHeading } from "@/components/site/Reveal";
import { RESTAURANT } from "@/lib/restaurant";

const TITLE = "Gallery | Cafeteria Nigeria, Victoria Island Lagos";
const DESCRIPTION =
  "Photographs of Cafeteria Nigeria — the dining room, breakfast plates, desserts and drinks in Victoria Island, Lagos.";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
      <SectionHeading
        script="Inside"
        eyebrow="Gallery"
        title="The Cafeteria Look"
        intro="Tap any photograph to view it full screen."
      />
      <div className="mt-12">
        <GalleryGrid />
      </div>

      <div className="mt-16 border border-border bg-card p-8 text-center">
        <p className="eyebrow">Follow along</p>
        <a
          href={`https://www.instagram.com/${RESTAURANT.instagramHandle.replace("@", "")}`}
          target="_blank"
          rel="noreferrer"
          className="mt-3 inline-flex items-center gap-2 font-display text-2xl text-foreground transition-colors hover:text-gold"
        >
          <Instagram className="size-5 text-gold" /> {RESTAURANT.instagramHandle}
        </a>
      </div>
    </section>
  );
}
