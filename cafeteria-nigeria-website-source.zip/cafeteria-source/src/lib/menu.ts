import acai from "@/assets/acai.jpg";
import benedict from "@/assets/benedict.jpg";
import bubbleTea from "@/assets/bubble-tea.jpg";
import chickenWaffle from "@/assets/chicken-waffle.jpg";
import coffee from "@/assets/coffee.jpg";
import dessert from "@/assets/dessert.jpg";
import panini from "@/assets/panini.jpg";
import pancakes from "@/assets/pancakes.jpg";
import skillet from "@/assets/skillet.jpg";
import smoothie from "@/assets/smoothie.jpg";

/**
 * Editable menu database.
 * Every item is a plain record: change name / price / description / tags here.
 * `price: null` means the price is not confirmed yet and the card shows
 * "Ask for price" instead of guessing a figure.
 */

export type MenuGroup = "Breakfast" | "Lunch & Dinner" | "Drinks" | "Desserts";
export type DietaryTag = "Vegetarian" | "Vegan" | "Contains Nuts" | "Seafood";

export type MenuItem = {
  id: string;
  name: string;
  category: string;
  group: MenuGroup;
  description?: string;
  price: number | null;
  image?: string;
  dietary?: DietaryTag[];
  featured?: boolean;
  available?: boolean;
  sortOrder?: number;
};

export type MenuCategory = { id: string; label: string; group: MenuGroup };

export const CATEGORIES: MenuCategory[] = [
  { id: "batters-toasts", label: "Batters & Toasts", group: "Breakfast" },
  { id: "benedict-toasts", label: "Benedict & Toasts", group: "Breakfast" },
  { id: "croissants-biscuits", label: "Croissants & Biscuits", group: "Breakfast" },
  { id: "traditional", label: "Traditional", group: "Breakfast" },
  { id: "fruit-bowls", label: "Fruit Bowls", group: "Breakfast" },
  { id: "skillets", label: "Skillets", group: "Breakfast" },
  { id: "breakfast-sides", label: "Breakfast Sides", group: "Breakfast" },
  { id: "lunch-dinner", label: "Lunch & Dinner", group: "Lunch & Dinner" },
  { id: "sides", label: "Sides", group: "Lunch & Dinner" },
  { id: "desserts", label: "Desserts", group: "Desserts" },
  { id: "smoothies", label: "Smoothies", group: "Drinks" },
  { id: "fresh-juices", label: "Fresh Juices", group: "Drinks" },
  { id: "coffee", label: "Coffee", group: "Drinks" },
  { id: "teas-herbs", label: "Teas & Herbs", group: "Drinks" },
  { id: "soft-drinks", label: "Soft Drinks", group: "Drinks" },
  { id: "bubble-tea", label: "Bubble Tea", group: "Drinks" },
  { id: "milkshakes", label: "Milkshakes", group: "Drinks" },
];

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

type Draft = Omit<MenuItem, "id" | "group" | "category"> & { name: string };

function build(categoryId: string, drafts: Draft[]): MenuItem[] {
  const category = CATEGORIES.find((c) => c.id === categoryId)!;
  return drafts.map((d, i) => ({
    available: true,
    ...d,
    id: `${categoryId}-${slug(d.name)}`,
    category: category.label,
    group: category.group,
    sortOrder: i,
  }));
}

export const MENU: MenuItem[] = [
  ...build("batters-toasts", [
    {
      name: "Berry Bliss Pancakes",
      description: "Vanilla dressing, blueberry compote, mascarpone.",
      price: 17100,
      image: pancakes,
      featured: true,
      dietary: ["Vegetarian"],
    },
    {
      name: "Fresh Berries Pancakes",
      description: "Fluffy pancakes with fresh berries.",
      price: 17100,
      image: pancakes,
      featured: true,
      dietary: ["Vegetarian"],
    },
    {
      name: "Fluffy Pancakes",
      description: "Pancakes, waffles or French toast with available toppings.",
      price: null,
      dietary: ["Vegetarian"],
    },
    { name: "Banana", description: "Fresh bananas.", price: null, dietary: ["Vegetarian", "Vegan"] },
    {
      name: "Fresh Berries",
      description: "Fresh berries.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Blueberry Madness",
      description: "Blueberry compote.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Strawberry Nutella",
      description: "Nutella and fresh strawberries.",
      price: null,
      dietary: ["Vegetarian", "Contains Nuts"],
    },
    {
      name: "Strawberry Banana",
      description: "Fresh strawberries and bananas.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Lemon Blueberry Ricotta",
      description: "Lemon, blueberries and ricotta.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Chicago Style Chicken & Waffle",
      description: "Chicken, waffles, house whipped butter and maple syrup.",
      price: null,
      image: chickenWaffle,
      featured: true,
    },
    {
      name: "Crispy Chicken & Stacks",
      description: "Crispy chicken with fluffy pancakes and house whipped butter.",
      price: null,
      image: chickenWaffle,
      featured: true,
    },
  ]),
  ...build("benedict-toasts", [
    {
      name: "Egg Benedict",
      description: "Texas toast, poached eggs, Louisiana hollandaise and bacon.",
      price: 16700,
      image: benedict,
      featured: true,
    },
    {
      name: "Steak Benedict",
      description: "Texas toast, grilled steak, bacon, poached eggs and Louisiana hollandaise.",
      price: 17300,
      image: benedict,
      featured: true,
    },
    {
      name: "Prawn Benedict",
      description: "Texas toast, grilled prawns, poached eggs and Louisiana hollandaise.",
      price: 18400,
      image: benedict,
      dietary: ["Seafood"],
    },
    {
      name: "Smashed Avocado Toast",
      description: "Avocado, olive oil and toasted pain de campagne.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Mushroom Avocado Toast",
      description: "Sautéed mushrooms, avocado, olive oil and basil.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
  ]),
  ...build("croissants-biscuits", [
    {
      name: "Southern Chicken Biscuit",
      description: "Buttermilk biscuits, crispy chicken and sautéed potatoes.",
      price: null,
    },
    {
      name: "Bacon, Egg & Cheese Biscuit",
      description: "Buttermilk biscuit, scrambled eggs, bacon, cheese and sautéed potatoes.",
      price: null,
    },
    {
      name: "Double Biscuit Platter",
      description:
        "Two buttermilk biscuits, scrambled egg and cheese, bacon, sausage and sautéed potatoes.",
      price: null,
    },
    {
      name: "The Breakfast Bagel",
      description:
        "Toasted bagel, bacon, egg, cheese, mashed potatoes, side salad, butter and jam.",
      price: null,
    },
    {
      name: "Elijah's Croissant Breakfast Sandwich",
      description: "Toasted croissant with bacon, egg, cheddar and mozzarella cheese.",
      price: null,
    },
    {
      name: "Nutella In-A-Croissant",
      description: "Toasted croissant with Nutella spread.",
      price: null,
      dietary: ["Vegetarian", "Contains Nuts"],
    },
  ]),
  ...build("traditional", [
    {
      name: "Traditional English Breakfast",
      description: "Bacon, eggs, sausage, mushrooms, baked beans, grilled tomatoes and toast.",
      price: null,
    },
    {
      name: "Not So Traditional English Breakfast",
      description:
        "Buttermilk pancakes or French toast, bacon, eggs, sausage, mushrooms, baked beans and grilled tomatoes.",
      price: null,
    },
    {
      name: "Noah's Garden Omelette",
      description:
        "Eggs, tomatoes, peppers, onions, mushrooms, mozzarella, cheddar, sautéed potatoes and mixed greens.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Loaded Brisket Omelette",
      description:
        "Eggs, shredded brisket, tomatoes, peppers, onions, mushrooms, mozzarella, cheddar, salsa, sautéed potatoes and mixed greens.",
      price: null,
    },
    {
      name: "Loaded Chicken Omelette",
      description:
        "Eggs, shredded chicken, tomatoes, peppers, onions, mushrooms, mozzarella, cheddar, salsa, sautéed potatoes and mixed greens.",
      price: null,
    },
  ]),
  ...build("fruit-bowls", [
    {
      name: "Very Berry Bowl",
      description: "Blueberry compote, Greek yogurt, granola and fresh berries.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Crunch Yogurt Bowl",
      description: "Greek yogurt, granola, fresh berries and shaved coconut.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Açaí Berry Bowl",
      description: "Açaí blend, coconut flakes, blueberries, strawberries, bananas and chia seeds.",
      price: null,
      image: acai,
      featured: true,
      dietary: ["Vegetarian", "Vegan"],
    },
  ]),
  ...build("skillets", [
    {
      name: "Pulled Beef Skillet",
      description:
        "Avocado, pulled beef, eggs, cheese, sautéed potatoes, jalapeños, cilantro, grilled onions, salsa and buttered toast.",
      price: null,
      image: skillet,
      featured: true,
    },
    {
      name: "Shredded Chicken Skillet",
      description:
        "Avocado, chicken, eggs, cheese, sautéed potatoes, jalapeños, cilantro, grilled onions, salsa and buttered toast.",
      price: null,
      image: skillet,
    },
    {
      name: "Mushroom Skillet",
      description:
        "Avocado, mushrooms, eggs, cheese, sautéed potatoes, jalapeños, cilantro, grilled onions, green peppers, salsa and buttered toast.",
      price: null,
      image: skillet,
      featured: true,
      dietary: ["Vegetarian"],
    },
  ]),
  ...build(
    "breakfast-sides",
    [
      "Buttermilk Biscuit",
      "Bacon",
      "Pork Sausage",
      "Chicken Sausage",
      "Egg",
      "Waffle",
      "French Toast",
      "Fluffy Pancakes",
      "Avocado",
      "Plain Croissant",
      "Mac & Cheese",
      "Sautéed Potatoes",
    ].map((name) => ({ name, price: null })),
  ),
  ...build("lunch-dinner", [
    {
      name: "Prawn + Pesto Panini",
      description:
        "Seared prawns with caramelized onions, basil, pesto sauce, tomatoes and house mayonnaise.",
      price: null,
      image: panini,
      dietary: ["Seafood"],
      featured: true,
    },
    {
      name: "Chicken Pesto Panini",
      description:
        "Grilled chicken, mozzarella cheese, red onions, tomato, mint, basil, olive oil and chipotle sauce.",
      price: null,
      image: panini,
    },
    {
      name: "Grilled Cheese Melt",
      description:
        "Toasted sourdough accompanied with fresh tomato sauces, gruyere, mozzarella and cheddar cheese.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Grilled PB&J",
      description: "Toasted bread with strawberry jam and honey-roasted peanut butter.",
      price: null,
      dietary: ["Vegetarian", "Contains Nuts"],
    },
    {
      name: "Mixed Chicken Salad",
      description:
        "Grilled chicken, romaine lettuce, cherry tomatoes, avocado, red onions, dried cranberries and garlic herb croutons.",
      price: null,
    },
    {
      name: "Southern Prawn Salad",
      description:
        "Seasoned grilled prawns, crispy lettuce, diced red onions, cherry tomatoes, avocado, celery, jalapeños, sliced cucumbers, dried cranberries and parmesan cheese.",
      price: null,
      dietary: ["Seafood"],
    },
    {
      name: "Mushroom House Salad",
      description:
        "Crisp lettuce, diced red onions, cherry tomatoes, sliced cucumbers, avocado, garlic herb croutons, parmesan cheese and dried cranberries.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Smith's Classic Chicken & French Fries",
      description:
        "Fried boneless chicken served with house sweet chili sauce or BBQ sauce and French fries.",
      price: null,
    },
    {
      name: "Elote",
      description: "Mexican street corn with house whipped mayonnaise, garnish and seasoning.",
      price: 2500,
      dietary: ["Vegetarian"],
    },
  ]),
  ...build("sides", [
    { name: "Elote", price: 2500, dietary: ["Vegetarian"] },
    { name: "Pork Sausage", price: 2000 },
    { name: "Chicken Sausage", price: 2000 },
    { name: "Bacon", price: 1500 },
    { name: "French Fries", price: 1500, dietary: ["Vegetarian", "Vegan"] },
    { name: "Sautéed Potatoes", price: 1500, dietary: ["Vegetarian", "Vegan"] },
    { name: "Fluffy Pancakes", price: 2000, dietary: ["Vegetarian"] },
    { name: "Waffle", price: 2000, dietary: ["Vegetarian"] },
    { name: "Eggs", price: 1500, dietary: ["Vegetarian"] },
  ]),
  ...build("desserts", [
    {
      name: "Sundance Sundae",
      description:
        "Creamy vanilla ice cream lightly drizzled with chocolate, strawberry or caramel syrup.",
      price: null,
      image: dessert,
      dietary: ["Vegetarian"],
    },
    {
      name: "Waffle Sundae",
      description:
        "Warm homemade waffle topped with vanilla ice cream and chocolate, strawberry or caramel syrup.",
      price: null,
      image: dessert,
      featured: true,
      dietary: ["Vegetarian"],
    },
  ]),
  ...build("smoothies", [
    {
      name: "Tropical Blended Smoothie",
      description: "Mango, pineapple and banana.",
      price: null,
      image: smoothie,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Strawberry Smoothie",
      description: "Strawberries and banana.",
      price: null,
      image: smoothie,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Royal Berry Smoothie",
      description: "Mixed berries and banana.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Paradise Smoothie",
      description: "Pineapple, mango and orange.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Smoothberry",
      description: "Strawberries, blueberries and yogurt.",
      price: null,
      dietary: ["Vegetarian"],
    },
    {
      name: "Smooth Sunrise",
      description: "Orange, strawberry and banana.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Go Kale",
      description: "Kale, apple, banana and pineapple.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
    {
      name: "Tropical Kale",
      description: "Kale, mango, pineapple and banana.",
      price: null,
      dietary: ["Vegetarian", "Vegan"],
    },
  ]),
  ...build(
    "fresh-juices",
    ["Orange", "Pineapple", "Ginger", "Pineapple & Ginger"].map((name) => ({
      name,
      price: null,
      dietary: ["Vegetarian", "Vegan"] as DietaryTag[],
    })),
  ),
  ...build(
    "coffee",
    [
      "Espresso",
      "Double Espresso",
      "Macchiato",
      "Double Macchiato",
      "Macchiato Caramel",
      "Mocha",
      "Double Mocha",
      "Cappuccino",
      "Double Cappuccino",
      "Caramel Cappuccino",
      "Café Latte",
      "Double Café Latte",
      "Americano",
      "Iced Americano",
      "Caramel Frappuccino",
      "Mocha Frappe",
      "Chai Latte",
      "Vanilla Chai Latte",
      "Hot Cocoa",
      "Baileys Iced Mocha",
    ].map((name, i) => (i === 0 ? { name, price: null, image: coffee } : { name, price: null })),
  ),
  ...build(
    "teas-herbs",
    [
      "Jasmine Green Tea",
      "Peppermint Tea",
      "Masala Chai",
      "Lemon Grass & Ginger",
      "Rose Black Tea",
      "Taiwanese Green Tea",
    ].map((name) => ({ name, price: null, dietary: ["Vegetarian", "Vegan"] as DietaryTag[] })),
  ),
  ...build(
    "soft-drinks",
    ["Soft Drinks", "Still Water", "Perrier", "Red Bull"].map((name) => ({ name, price: null })),
  ),
  ...build(
    "bubble-tea",
    [
      { name: "Original Milk Tea", featured: true, image: bubbleTea },
      { name: "Taro" },
      { name: "Matcha" },
      { name: "Mango Iced Tea" },
      { name: "Passion Fruit Iced Tea" },
      { name: "Thai Black Tea (Low Sugar)" },
    ].map((d) => ({
      ...d,
      price: null,
      description: "Choose sweetness and toppings.",
      dietary: ["Vegetarian"] as DietaryTag[],
    })),
  ),
  ...build(
    "milkshakes",
    ["Vanilla", "Strawberry", "Chocolate", "Cookie Crumble", "Oreo Madness"].map((name) => ({
      name,
      price: null,
      dietary: ["Vegetarian"] as DietaryTag[],
    })),
  ),
];

export const FEATURED = MENU.filter((i) => i.featured && i.image).slice(0, 8);

export function formatPrice(price: number | null) {
  if (price === null) return "Ask for price";
  return `₦${price.toLocaleString("en-NG")}`;
}

/* ---- Bubble Tea Spot ---- */

export const BUBBLE_TEA = {
  milkTea: [
    "Original Milk Tea",
    "Coconut Caramel",
    "Taro",
    "Vanilla",
    "Strawberry",
    "Chocolate",
    "Coconut",
    "Caramel",
    "Mango",
    "Lychee",
    "Strawberry Vanilla",
    "Caramel Vanilla",
    "Honey Dew",
    "Coffee",
    "Mocha",
    "Thai",
    "Avocado",
    "Matcha",
    "Hazelnut",
    "Lavender",
    "Banana",
    "Papaya",
    "Hokkaido",
    "Durian",
  ],
  icedTea: [
    "Mango",
    "Passion Fruit",
    "Strawberry",
    "Ginger Green",
    "Lemonade",
    "Green Apple",
    "Lychee",
    "Pomegranate",
    "Kiwi",
    "Blueberry",
    "Green Tea",
    "Peach",
    "Raspberry",
    "Lemon Tea",
    "Orange",
    "Hibiscus",
    "Pineapple",
    "Guava",
    "Arnold Palmer",
  ],
  lowSugar: [
    "Original Milk Tea",
    "Thai Black Tea",
    "Taiwanese Green Tea",
    "Ginger Green Tea",
    "Ginger Black Tea",
    "Passion Fruit",
    "Lemon Grass & Ginger",
    "Tropical Fruit",
    "Rose Black Tea",
    "Jasmine Green Tea",
    "Peppermint Tea",
    "Masala Chai",
    "Strawberry & Raspberry",
  ],
  sweetness: ["Sweet", "Mid-Sweet", "Unsweetened"],
  toppings: ["Tapioca Pearls", "Popping Boba", "Grass Jelly", "Coconut Jelly", "Aloe Vera"],
};

/* ---- Build Your Own Smoothie ---- */

export const SMOOTHIE_BASES = ["Strawberry", "Mango", "Banana", "Pineapple", "Mixed Berries"];
export const SMOOTHIE_EXTRAS: { name: string; surcharge: number | null }[] = [
  { name: "Greek Yogurt", surcharge: null },
  { name: "Kale", surcharge: null },
  { name: "Avocado", surcharge: null },
  { name: "Chia Seeds", surcharge: null },
  { name: "Peanut Butter", surcharge: null },
  { name: "Protein Powder", surcharge: null },
];
